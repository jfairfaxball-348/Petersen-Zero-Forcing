# Next mathematics target — 23 September 2026

**Recommendation: attack Conjecture 5 of Arnav Krishnan on the zero-forcing number of generalized Petersen graphs.**

**Decision: READY_FOR_PILOT.** This is a recommendation for one bounded research session. It is not a claim that the conjecture is easy, proved, or guaranteed to produce a paper. No repository was created, and no Lean proof or submission was made.

## The target

For each integer n >= 13, determine whether **Z(P(n,3)) = 8**.

P(n,3) has vertices u_i,v_i indexed modulo n, with edges u_i u_(i+1), u_i v_i and v_i v_(i+3). A blue vertex colours its unique white neighbour blue. Z is the minimum initial blue count that eventually colours everything.

Krishnan's July 2026 preprint [1] gives an eight-vertex construction, exact values through n=20, and the open lower bound. It corrects a 2020 claim [2]. Targeted searches found no later resolution; unpublished work remains possible.

## Why this is the leader

- **A precise missing theorem:** exclude every seven-vertex starting set for arbitrary n, or exhibit one that succeeds for an admissible n. By monotonicity, excluding sets of size seven also excludes smaller ones.
- **A manageable discovery space:** rotational symmetry and the first possible force give a complete reduction for finite searches. The reduction is explained below.
- **A structural lead:** our selection screen suggests investigating a uniform bound on how many vertices seven seeds can ever colour.
- **Relevant existing experience:** the Fischer project developed zero-forcing closure, forts, finite certificates and kernel-only verification. Those ideas should transfer. The repository's current APIs were not inspected here, so direct code reuse remains to be checked.
- **A clear research contribution:** a uniform proof or a counterexample would settle a specifically stated conjecture. Extra finite confirmations alone would not meet this project's publication goal.

The main risk is the passage from finite computations to arbitrary n. An increasing table of successful checks does not solve that problem. The pilot must produce a lemma or a sound finite reduction that addresses it.

## What was actually computed in this session

Two separately implemented closure routines were used: C++ with bitmasks and sequential forces, and Python with ordinary sets and simultaneous rounds. These are independent implementations, not an independent human or agent audit.

| n | Seven-seed screen | Largest closure in the complete screen | Verification scope |
|---|---|---:|---|
| 10 | No forcing seven-set | 16 | C++ reduced search; Python checked all 77,520 seven-sets |
| 11 | A forcing seven-set found | Not exhaustively maximised | Python checked its closure and all six-sets fail |
| 12 | A forcing seven-set found | Not exhaustively maximised | Python checked its closure and all six-sets fail |
| 13 | No forcing seven-set | 18 | Complete reduced searches in both implementations |
| 20 | No forcing seven-set | 16 | C++ complete reduced search; Python checked a maximising witness |
| 21 | No forcing seven-set | 16 | Complete reduced searches in both implementations |
| 22 | No forcing seven-set | 16 | C++ complete reduced search; Python checked a maximising witness |
| 23 | No forcing seven-set | 16 | C++ complete reduced search; Python checked a maximising witness |
| 24 | No forcing seven-set | 16 | C++ complete reduced search; Python checked a maximising witness |

The Python program also checked the eight-consecutive-outer-vertices construction for each n from 9 to 100. Those checks concern just one specified set per graph; they are not exhaustive searches at those sizes.

The interesting observation is that seven seeds colour at most 16 vertices for each tested n from 20 through 24. This suggests the **unproved working hypothesis**

> For n >= 20 and |S| = 7, the zero-forcing closure of S in P(n,3) has at most 16 vertices.

If established uniformly, this would supply the desired lower bound in that range; the remaining finite cases would still need certified treatment. The hypothesis may fail beyond the tested range. No extrapolation is asserted as a theorem.

### Why the finite search covers all seven-sets

A successful seven-set has a first force, since the graph has more than seven vertices. The source of that force and two of its three neighbours must already be blue. Rotate its index to zero; its type is either u_0 or v_0. There are three pairs of neighbours for each type. Complete each of these six triples with every choice of four remaining vertices.

Thus at most 6 * binomial(2n-3,4) closures suffice to detect any forcing seven-set. Duplicate sets are harmless. Seven-sets with no available first force have closure size seven, so omitting them cannot hide a larger closure.

For n=24, this is 893,970 tested entries rather than all 73,629,072 seven-subsets. This is a search reduction, not a solution of the conjecture. Its completeness argument must also be formalised if used inside the final proof.

## Fresh shortlist and alternatives

| Rank | Precisely identified open target | Assessment |
|---|---|---|
| 1 | Krishnan, Conjecture 5: Z(P(n,3)) = 8 for all n >= 13 [1] | Best fit: one repeating graph family, inexpensive finite screening, and a possible uniform closure bound. |
| 2 | Ferrero–Hall–Hogben–Hunnell–Small, Conjecture 1.8: a connected graph whose every inclusion-minimal standard forcing set finishes in one round is a standard fast join [3] | A plausible finite-counterexample target. The paper already handles joins, so any counterexample must have connected complement. A positive proof requires a structural classification across all graphs. |
| 3 | Brimkov–Cameron–Grubbs, Conjecture 4.4: among minimum zero-forcing sets of Q_d, the parallel propagation times are exactly 1,...,2^(d-2), for d >= 2 [4] | Exact and symmetric, but the next dimension beyond the published checks is a 64-vertex graph. A counterexample to the claimed maximum is easier to certify than exhaustive confirmation. |

In [3], a standard fast join is a complete graph of order at least two, or a join of at least two factors, each an independent set of size at least two or two disjoint cliques each of size at least two. A join adds every edge between different factors. “Minimal” means no proper subset still forces; it does not mean minimum cardinality.

For [4], Q_d is the graph on binary strings of length d, adjacent when they differ in one coordinate. The minimum forcing-set size is 2^(d-1). The later computational paper [5] reports the conjectured interval through d=5. A witness lasting at least 17 rounds in Q_6 would refute the maximum-time claim, provided its starting set is certified minimum. Naively considering all binomial(64,32) starting sets is not a practical pilot. These alternatives received literature screening only; no experiments were run on them.

### Candidates excluded

- The earlier three targets—2-homogeneous cubic colouring, strong colouring of graph truncations, and tree stacking—were excluded from this fresh search. This audit does not assert a final outcome for the latter two pilots.
- Minimal-fort counting on trees is not a fresh open target: Kenter's May 2026 paper announces a resolution of the relevant conjecture [6].
- Exact isolation-game values for paths and cycles have already been addressed in the follow-up paper [7].
- An older maximum-nullity paper [8] was checked for an overlooked Petersen result. Its displayed exact subfamilies do not establish the proposed k=3 statement. This is a targeted check, not an exhaustive classification of the minimum-rank literature.

## Bounded next-session brief

**Objective:** decide whether a uniform lower-bound proof is realistically accessible. Keep this as a pilot; do not create a repository or begin a long formalisation programme.

1. Read [1], especially Conjecture 5 and the failed step identified in the old argument. Refresh the status search once before investing further.
2. Reproduce the attached computations. Fill the finite gaps n=14,...,19 and, if useful, extend screening only through n=30. Limit computation to two CPU-hours and 4 GiB RAM; stop incomplete runs honestly at the cap.
3. Try to explain the observed closure bound through local forcing configurations or forts. A fort is a nonempty set F such that no vertex outside F has exactly one neighbour in F. A fort disjoint from S certifies that S cannot force the graph.
4. Seek one explicit lemma: a uniform closure bound, a finite collection of fort templates with a proved coverage argument, or a sound finite reduction of all seed arrangements. Cyclic wrap-around and arbitrarily large gaps between seeds must be handled, not assumed away.
5. If using a finite-state method, prove that its state records all information required by the forcing rule. Fixed edge span alone is not a completeness proof. Do not promote an experimentally stable transition table into an invariant.
6. Finish with one verdict: PILOT_POSITIVE if there is a verified counterexample or a concrete uniform lemma with a checked proof; PILOT_NEGATIVE if the only output is more finite confirmations; PILOT_INCONCLUSIVE if a specified missing resource prevented the bounded test.

Do not automatically extend the numerical limit, replace the stated conjecture, or turn the closure hypothesis into an unsupported assertion. If the stronger closure hypothesis fails, record the failure separately from the original conjecture.

## Route to Lean, Palomar and a preprint

After a positive pilot, develop a readable mathematical proof first. Define P(n,3) over a finite cyclic index type, connect the executable closure to the standard forcing relation, and formalise the actual new theorem. Prefer structural lemmas plus small checked certificates. If a seven-set counterexample emerges, its forcing sequence suffices to refute the conjecture; computing the exact new zero-forcing number is optional.

Recheck the full transitive axiom dependencies. The intended trust boundary permits only propext, Classical.choice and Quot.sound; external solver results must become checked evidence. Keep the Palomar Challenge statement small and faithful, with the full quantified result visible. Palomar also requires a plausible research audience; registration alone does not establish novelty or expert peer review [9].

A successful result could support a short math.CO preprint explaining the open question, the new proof or counterexample, and reproducibility/formal verification. arXiv moderates research significance and presentation, and first submissions may need endorsement [10,11]. This is a plausible publication route, not guaranteed acceptance. A larger finite table by itself is below our chosen success threshold.

## Reproduce the selection screen

The accompanying archive contains the two programs and their raw JSON outputs. From its extracted directory:

```bash
g++ -std=c++17 -O3 -Wall -Wextra -pedantic petersen_screen.cpp -o petersen_screen
./petersen_screen > petersen_screen_results.json
python3 petersen_verify.py
```

The C++ program intentionally uses a fixed list of nine sizes and assumes fewer than 64 vertices. Do not extend it beyond its stated representation limit. Timing values depend on the machine. No Lean proof, solver certificate, or proof of the infinite conjecture is included.

## Primary sources checked

1. A. Krishnan, July 2026, [Petersen correction and Conjecture 5](https://arxiv.org/pdf/2607.19412), arXiv:2607.19412v1.
2. S. Rashidi, N. Shajareh Poursalavati and M. Tavakkoli, 2020, [original Petersen article](https://dergipark.org.tr/tr/download/article-file/1078628), especially Theorem 3.6.
3. D. Ferrero et al., November 2025, [fixed propagation time and fast joins](https://arxiv.org/html/2511.16335v1), Conjecture 1.8 and Theorem 5.10.
4. B. Brimkov, T. R. Cameron and O. Grubbs, July 2025, [hypercube forts and propagation](https://arxiv.org/html/2507.10826v1), Conjecture 4.4.
5. T. R. Cameron and J. Pulaj, August 2025, [integer programming models for zero forcing](https://arxiv.org/pdf/2508.07293), Section 8.3.
6. F. H. J. Kenter, May 2026, [minimal forts on trees](https://arxiv.org/abs/2605.07298).
7. C. Bujtas, T. Dravec and M. A. Henning, [isolation-game follow-up](https://arxiv.org/pdf/2507.08503), current version.
8. J. S. Alameda et al., 2018, [maximum nullity and zero forcing](https://derekyoungmath.github.io/files/MR3760976.pdf), Section 2.
9. [Palomar submission policy](https://github.com/PalomarRegistry/PalomarPolicy/blob/main/CONTRIBUTING.md), accessed 23 September 2026.
10. [arXiv moderation policy](https://info.arxiv.org/help/moderation/index.html), accessed 23 September 2026.
11. [arXiv endorsement](https://info.arxiv.org/help/endorsement.html), accessed 23 September 2026.
