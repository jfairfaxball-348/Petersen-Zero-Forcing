"""Independent set-based complete reduced scans for n=13,...,30."""
import importlib.util
import json
from pathlib import Path

spec = importlib.util.spec_from_file_location('supplied_verifier', 'input/petersen_verify.py')
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)
rows = json.loads(Path('results/extended_screen.json').read_text())
checks = []
for row in rows:
    n = row['n']
    assert len(v.close(range(8), v.graph(n))) == 2*n
    assert sorted(v.close(row['maximizing_seed'],v.graph(n))) == row['closure']
    result = v.scan(n, 7, True)
    assert result['maximum_closure'] == row['maximum_closure_in_scan']
    assert result['tested'] == row['tested_with_duplicates']
    checks.append(result)
out = dict(status='passed',scans=checks,scope='All n=13,...,30, seven seeds; duplicate entries allowed')
Path('results/finite_python_verification.json').write_text(json.dumps(out,indent=2)+'\n')
